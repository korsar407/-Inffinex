Sample configuration files for:

SystemD: axscoind.service
Upstart: axscoind.conf
OpenRC:  axscoind.openrc
         axscoind.openrcconf
CentOS:  axscoind.init

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
